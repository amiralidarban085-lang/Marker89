package com.example.markit

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

data class Mark(
    val points: MutableList<PointF>,
    val color: Int,
    val width: Float
)

class HighlighterView(context: Context) : View(context) {

    private var page: Bitmap? = null
    private val marks = mutableListOf<Mark>()
    private var current: Mark? = null

    var markerColor: Int = Color.YELLOW
    var markerWidth: Float = 24f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val imageRect = RectF()

    fun setPage(bitmap: Bitmap) {
        page = bitmap
        marks.clear()
        current = null
        invalidate()
    }

    fun undo() {
        if (marks.isNotEmpty()) {
            marks.removeAt(marks.lastIndex)
            invalidate()
        }
    }

    private fun fitImage() {
        val bitmap = page ?: return
        val scale = min(
            width.toFloat() / bitmap.width,
            height.toFloat() / bitmap.height
        )
        val w = bitmap.width * scale
        val h = bitmap.height * scale
        imageRect.set(
            (width - w) / 2f,
            (height - h) / 2f,
            (width + w) / 2f,
            (height + h) / 2f
        )
    }

    private fun buildPath(points: List<PointF>): Path {
        val path = Path()
        path.moveTo(points.first().x, points.first().y)
        for (i in 1 until points.size) {
            val p = points[i]
            val prev = points[i - 1]
            path.quadTo(prev.x, prev.y, (prev.x + p.x) / 2f, (prev.y + p.y) / 2f)
        }
        path.lineTo(points.last().x, points.last().y)
        return path
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        fitImage()

        val bitmap = page ?: return
        canvas.drawColor(Color.rgb(245, 245, 245))
        canvas.drawBitmap(bitmap, null, imageRect, null)

        val sx = imageRect.width() / bitmap.width
        val sy = imageRect.height() / bitmap.height

        canvas.save()
        canvas.translate(imageRect.left, imageRect.top)
        canvas.scale(sx, sy)

        (marks + listOfNotNull(current)).forEach { mark ->
            if (mark.points.isEmpty()) return@forEach
            paint.color = mark.color
            paint.alpha = 105
            paint.strokeWidth = mark.width
            canvas.drawPath(buildPath(mark.points), paint)
        }

        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bitmap = page ?: return false
        fitImage()

        val x = (event.x - imageRect.left) * bitmap.width / imageRect.width()
        val y = (event.y - imageRect.top) * bitmap.height / imageRect.height()

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                if (!imageRect.contains(event.x, event.y)) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                current = Mark(mutableListOf(PointF(x, y)), markerColor, markerWidth)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                current?.points?.add(PointF(x, y))
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                current?.points?.add(PointF(x, y))
                current?.let { marks.add(it) }
                current = null
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                current = null
                invalidate()
                return true
            }
        }
        return true
    }

    fun exportBitmap(): Bitmap? {
        val original = page ?: return null
        val output = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)

        marks.forEach { mark ->
            if (mark.points.isEmpty()) return@forEach
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = mark.color
                alpha = 105
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                strokeWidth = mark.width
            }
            canvas.drawPath(buildPath(mark.points), p)
        }
        return output
    }
}
