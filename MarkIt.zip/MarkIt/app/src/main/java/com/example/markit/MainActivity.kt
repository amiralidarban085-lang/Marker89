package com.example.markit

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {

    private lateinit var highlighter: HighlighterView
    private var renderer: PdfRenderer? = null
    private var pdfFile: File? = null
    private var pdfPageIndex = 0

    private val openImage = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { loadImage(it) } }

    private val openPdf = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { loadPdf(it) } }

    private val saveImage = registerForActivityResult(
        ActivityResultContracts.CreateDocument("image/png")
    ) { uri: Uri? -> uri?.let { saveAnnotatedImage(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        highlighter = HighlighterView(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        fun button(text: String, action: () -> Unit) =
            Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            }

        fun row() = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val toolbar = row()
        toolbar.addView(button("عکس") { openImage.launch(arrayOf("image/*")) })
        toolbar.addView(button("PDF") { openPdf.launch(arrayOf("application/pdf")) })
        toolbar.addView(button("صفحه قبل") { showPdfPage(pdfPageIndex - 1) })
        toolbar.addView(button("صفحه بعد") { showPdfPage(pdfPageIndex + 1) })
        root.addView(toolbar)

        val colors = row()
        listOf(
            "زرد" to Color.YELLOW,
            "سبز" to Color.GREEN,
            "صورتی" to Color.MAGENTA,
            "آبی" to Color.CYAN
        ).forEach { (name, color) ->
            colors.addView(button(name) { highlighter.markerColor = color })
        }
        root.addView(colors)

        val actions = row()
        actions.addView(button("ضخامت +") {
            highlighter.markerWidth = (highlighter.markerWidth + 4f).coerceAtMost(100f)
        })
        actions.addView(button("ضخامت -") {
            highlighter.markerWidth = (highlighter.markerWidth - 4f).coerceAtLeast(8f)
        })
        actions.addView(button("برگشت") { highlighter.undo() })
        actions.addView(button("ذخیره") { saveImage.launch("highlighter.png") })
        root.addView(actions)

        root.addView(
            highlighter,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
    }

    private fun loadImage(uri: Uri) {
        try {
            val bitmap = contentResolver.openInputStream(uri)
                ?.use { BitmapFactory.decodeStream(it) }
            if (bitmap == null) {
                toast("تصویر قابل خواندن نیست")
                return
            }
            closePdf()
            highlighter.setPage(bitmap)
        } catch (e: Exception) {
            toast("خطا در باز کردن تصویر")
        }
    }

    private fun loadPdf(uri: Uri) {
        try {
            closePdf()
            val file = File(cacheDir, "selected.pdf")
            contentResolver.openInputStream(uri)!!.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            pdfFile = file
            val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(descriptor)
            showPdfPage(0)
        } catch (e: Exception) {
            closePdf()
            toast("خطا در باز کردن PDF")
        }
    }

    private fun showPdfPage(index: Int) {
        val pdf = renderer ?: return
        if (index !in 0 until pdf.pageCount) {
            toast("صفحه دیگری وجود ندارد")
            return
        }
        try {
            pdf.openPage(index).use { page ->
                val scale = minOf(2f, 1800f / page.width, 2400f / page.height)
                val bitmap = Bitmap.createBitmap(
                    (page.width * scale).toInt().coerceAtLeast(1),
                    (page.height * scale).toInt().coerceAtLeast(1),
                    Bitmap.Config.ARGB_8888
                )
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                highlighter.setPage(bitmap)
                pdfPageIndex = index
            }
        } catch (e: Exception) {
            toast("خطا در نمایش صفحه")
        }
    }

    private fun saveAnnotatedImage(uri: Uri) {
        try {
            val bitmap = highlighter.exportBitmap()
            if (bitmap == null) {
                toast("ابتدا یک عکس یا PDF باز کنید")
                return
            }
            contentResolver.openOutputStream(uri)?.use { output ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
            } ?: throw IllegalStateException("Output stream unavailable")
            bitmap.recycle()
            toast("تصویر ذخیره شد")
        } catch (e: Exception) {
            toast("ذخیره تصویر ناموفق بود")
        }
    }

    private fun closePdf() {
        renderer?.close()
        renderer = null
        pdfFile?.delete()
        pdfFile = null
        pdfPageIndex = 0
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        closePdf()
        super.onDestroy()
    }
}
